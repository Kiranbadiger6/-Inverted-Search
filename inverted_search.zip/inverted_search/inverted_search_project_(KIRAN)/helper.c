#include "common.h"

/* Function to initialize hash table */
void initialize_hash(hash_t *arr)
{
    for (int i = 0; i < HASH_SIZE; i++)
    {
        arr[i].index = i;
        arr[i].h_link = NULL;
    }
}

/* Function to get hash index */
int get_index(char ch)
{
    ch = tolower(ch);

    if (ch >= 'a' && ch <= 'z')
        return ch - 'a';

    else if (ch >= '0' && ch <= '9')
        return 26;

    else
        return 27;
}

/* Function to create a sub node */
sub_node *create_sub_node(char *fname)
{
    sub_node *new = malloc(sizeof(sub_node));

    if (new == NULL)
        return NULL;

    strcpy(new->filename, fname);
    new->word_count = 1;
    new->sub_link = NULL;

    return new;
}

/* Function to create a main node */
main_node *create_main_node(char *word, char *fname)
{
    main_node *new = malloc(sizeof(main_node));

    if (new == NULL)
        return NULL;

    strcpy(new->word, word);
    new->file_count = 1;
    new->main_link = NULL;

    new->sub_link = create_sub_node(fname);

    if (new->sub_link == NULL)
    {
        free(new);
        return NULL;
    }

    return new;
}

/* Check whether file already exists in database */
int file_exists_in_database(hash_t *arr, char *filename)
{
    for (int i = 0; i < HASH_SIZE; i++)
    {
        main_node *mtemp = arr[i].h_link;

        while (mtemp)
        {
            sub_node *stemp = mtemp->sub_link;

            while (stemp)
            {
                if (strcmp(stemp->filename, filename) == 0)
                    return 1;

                stemp = stemp->sub_link;
            }

            mtemp = mtemp->main_link;
        }
    }

    return 0;
}