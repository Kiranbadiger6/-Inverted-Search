#include "common.h"

Status update_database(hash_t *arr, char *filename)
{
    FILE *fp = fopen(filename, "r");

    if (fp == NULL)
        return FAILURE;

    char line[500];

    while (fgets(line, sizeof(line), fp))
    {
        char *token;

        /* Remove newline */
        line[strcspn(line, "\n")] = '\0';

        /* Skip # */
        token = strtok(line + 1, ";");

        if (token == NULL)
            continue;

        /* Get hash index */
        int index;

        if (token[0] >= 'a' && token[0] <= 'z')
            index = token[0] - 'a';
        else if (isdigit(token[0]))
            index = 26;
        else
            index = 27;

        /* Get word */
        token = strtok(NULL, ";");

        if (token == NULL)
            continue;

        char word[SIZE];
        strcpy(word, token);

        /* Get file count */
        token = strtok(NULL, ";");

        if (token == NULL)
            continue;

        int file_count = atoi(token);

        /* Create main node */
        main_node *new_main =
            malloc(sizeof(main_node));

        if (new_main == NULL)
        {
            fclose(fp);
            return FAILURE;
        }

        strcpy(new_main->word, word);
        new_main->file_count = file_count;
        new_main->sub_link = NULL;
        new_main->main_link = NULL;

        sub_node *last = NULL;

        /* Create sub nodes */
        for (int i = 0; i < file_count; i++)
        {
            /* Filename */
            token = strtok(NULL, ";");

            if (token == NULL)
                break;

            char fname[SIZE];
            strcpy(fname, token);

            /* Word count */
            token = strtok(NULL, ";");

            if (token == NULL)
                break;

            int count = atoi(token);

            /* Create sub node */
            sub_node *new_sub =
                malloc(sizeof(sub_node));

            if (new_sub == NULL)
            {
                fclose(fp);
                return FAILURE;
            }

            strcpy(new_sub->filename, fname);
            new_sub->word_count = count;
            new_sub->sub_link = NULL;

            /* Insert sub node */
            if (new_main->sub_link == NULL)
            {
                new_main->sub_link = new_sub;
                last = new_sub;
            }
            else
            {
                last->sub_link = new_sub;
                last = new_sub;
            }
        }

        /* Insert main node into hash table */
        if (arr[index].h_link == NULL)
        {
            arr[index].h_link = new_main;
        }
        else
        {
            main_node *temp = arr[index].h_link;

            while (temp->main_link)
                temp = temp->main_link;

            temp->main_link = new_main;
        }
    }

    fclose(fp);

    return SUCCESS;
}