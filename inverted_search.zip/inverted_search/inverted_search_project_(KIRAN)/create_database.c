#include "common.h"

Status create_database(file_node *head, hash_t *arr)
{
    char word[SIZE];

    while (head)
    {
        /*
         * If file is already present in database,
         * skip it.
         *
         * This is required for:
         * Update -> Create
         */
        if (file_exists_in_database(arr, head->file))
        {
            head = head->link;
            continue;
        }

        FILE *fp = fopen(head->file, "r");

        if (fp == NULL)
        {
            head = head->link;
            continue;
        }

        while (fscanf(fp, "%49s", word) == 1)
        {
            /* Convert word to lowercase */
            for (int i = 0; word[i]; i++)
                word[i] = tolower(word[i]);

            int index = get_index(word[0]);

            main_node *mtemp = arr[index].h_link;
            main_node *mprev = NULL;

            /* Search for word in hash table */
            while (mtemp)
            {
                if (strcmp(mtemp->word, word) == 0)
                    break;

                mprev = mtemp;
                mtemp = mtemp->main_link;
            }

            /* Word not present */
            if (mtemp == NULL)
            {
                main_node *new_main =
                    create_main_node(word, head->file);

                if (new_main == NULL)
                {
                    fclose(fp);
                    return FAILURE;
                }

                if (arr[index].h_link == NULL)
                {
                    arr[index].h_link = new_main;
                }
                else
                {
                    mprev->main_link = new_main;
                }
            }
            else
            {
                /* Search filename in sub list */
                sub_node *stemp = mtemp->sub_link;
                sub_node *sprev = NULL;

                while (stemp)
                {
                    if (strcmp(stemp->filename, head->file) == 0)
                        break;

                    sprev = stemp;
                    stemp = stemp->sub_link;
                }

                /* File already exists */
                if (stemp)
                {
                    stemp->word_count++;
                }
                else
                {
                    sub_node *new_sub =
                        create_sub_node(head->file);

                    if (new_sub == NULL)
                    {
                        fclose(fp);
                        return FAILURE;
                    }

                    sprev->sub_link = new_sub;
                    mtemp->file_count++;
                }
            }
        }

        fclose(fp);

        head = head->link;
    }

    return SUCCESS;
}