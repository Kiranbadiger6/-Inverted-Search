#include "common.h"

void display_database(hash_t *arr)
{
    printf("\n");
    printf("-------------------------------------------------------------------------------------------------\n");
    printf("%-8s %-20s %-12s %-20s %-10s\n", "Index", "Word", "File Count", "Filename", "Word Count");
    printf("-------------------------------------------------------------------------------------------------\n");

    for (int i = 0; i < HASH_SIZE; i++)
    {
        if (arr[i].h_link == NULL) // Skip empty buckets
            continue;

        main_node *mtemp = arr[i].h_link; // Point to first main node

        while (mtemp)
        {
            sub_node *stemp = mtemp->sub_link; // Point to first sub node

            /* Print first subnode along with main node */
            printf("%-8d %-20s %-12d %-20s %-10d\n",i,mtemp->word,mtemp->file_count,stemp->filename,stemp->word_count);

            stemp = stemp->sub_link; // Move to next sub node

            /* Print remaining subnodes */
            while (stemp)
            {
                printf("%-8s %-20s %-12s %-20s %-10d\n","","","",stemp->filename,stemp->word_count);

                stemp = stemp->sub_link;
            }

            mtemp = mtemp->main_link;  // Move to next main node
        }

        printf("-------------------------------------------------------------------------------------------------\n");
    }
    
}