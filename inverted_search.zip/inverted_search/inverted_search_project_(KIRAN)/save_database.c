#include "common.h"

Status save_database(hash_t *arr, char *filename)
{
    FILE *fp = fopen(filename, "w"); // Open file in write mode

    if (fp == NULL) // Check whether file is opened successfully
        return FAILURE;

    for (int i = 0; i < HASH_SIZE; i++)
    {
        main_node *mtemp = arr[i].h_link; // Point to first main node

        while (mtemp)
        {
            /* Print bucket index */
            if (i >= 0 && i <= 25) // Check if bucket belongs to alphabets
                fprintf(fp, "#%c;", i + 'a');
            else if (i == 26) // Check if bucket belongs to digits
                fprintf(fp, "#0;");
            else
                fprintf(fp, "#$;"); // Write special character index

            /* Print word and file count */
            fprintf(fp, "%s;%d;", mtemp->word, mtemp->file_count);

            /* Print all sub nodes */
            sub_node *stemp = mtemp->sub_link;

            while (stemp)
            {
                fprintf(fp, "%s;%d;", stemp->filename, stemp->word_count); // Write filename and word count
                stemp = stemp->sub_link;  // Move to next sub node
            }

            fprintf(fp, "#\n"); // End current database record

            mtemp = mtemp->main_link;  // Move to next main node
        }
    }

    fclose(fp);

    return SUCCESS;
}