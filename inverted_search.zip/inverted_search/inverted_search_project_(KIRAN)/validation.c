#include "common.h"

/* Check duplicate file names */
Status check_duplicate(file_node *head, char *fname)
{
    while (head)
    {
        if (strcmp(head->file, fname) == 0)
            return SUCCESS;

        head = head->link;
    }

    return FAILURE;
}

/* Insert file at last */
Status insert_at_last(file_node **head, char *fname)
{
    file_node *new = malloc(sizeof(file_node));

    if (new == NULL)
        return FAILURE;

    strcpy(new->file, fname);
    new->link = NULL;

    if (*head == NULL)
    {
        *head = new;
        return SUCCESS;
    }

    file_node *temp = *head;

    while (temp->link)
        temp = temp->link;

    temp->link = new;

    return SUCCESS;
}

/* Validate all input files */
Status validation(char *argv[], file_node **head)
{
    int i = 1;

    while (argv[i] != NULL)
    {
        int len = strlen(argv[i]);

        /* Check exact .txt extension */
        if (len < 4 || strcmp(argv[i] + len - 4, ".txt") != 0)
        {
            printf("%s -> Invalid file extension\n", argv[i]);
            i++;
            continue;
        }

        /* Open file */
        FILE *fp = fopen(argv[i], "r");

        if (fp == NULL)
        {
            printf("%s -> File not found\n", argv[i]);
            i++;
            continue;
        }

        /* Check empty file */
        fseek(fp, 0, SEEK_END);

        if (ftell(fp) == 0)
        {
            printf("%s -> Empty file\n", argv[i]);
            fclose(fp);
            i++;
            continue;
        }

        fclose(fp);

        /* Check duplicate input file */
        if (check_duplicate(*head, argv[i]) == SUCCESS)
        {
            printf("%s -> Duplicate file\n", argv[i]);
            i++;
            continue;
        }

        /* Insert valid file */
        if (insert_at_last(head, argv[i]) == SUCCESS)
        {
            printf("%s -> Successfully added\n", argv[i]);
        }

        i++;
    }

    if (*head == NULL)
        return FAILURE;

    return SUCCESS;
}