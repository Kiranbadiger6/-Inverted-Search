#ifndef common_H
#define common_H

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>

#define SIZE 50
#define HASH_SIZE 28

typedef enum
{
    FAILURE,
    SUCCESS
} Status;

/*------------ File Linked List ------------*/

typedef struct filenode
{
    char file[SIZE];
    struct filenode *link;
} file_node;

/*------------ Sub Node ------------*/

typedef struct subnode
{
    char filename[SIZE];
    int word_count;
    struct subnode *sub_link;
} sub_node;

/*------------ Main Node ------------*/

typedef struct mainnode
{
    char word[SIZE];
    int file_count;
    sub_node *sub_link;
    struct mainnode *main_link;
} main_node;

/*------------ Hash Table ------------*/

typedef struct hash
{
    int index;
    main_node *h_link;
} hash_t;

/* validation.c */
Status validation(char *argv[], file_node **head);
Status insert_at_last(file_node **head, char *fname);
Status check_duplicate(file_node *head, char *fname);

/* helper.c */
int get_index(char ch);
void initialize_hash(hash_t *arr);
main_node *create_main_node(char *word, char *fname);
sub_node *create_sub_node(char *fname);

/* NEW */
int file_exists_in_database(hash_t *arr, char *filename);

/* create_database.c */
Status create_database(file_node *head, hash_t *arr);

/* display_database.c */
void display_database(hash_t *arr);

/* save_database.c */
Status save_database(hash_t *arr, char *filename);

/* read_database.c */
Status update_database(hash_t *arr, char *filename);

/* search_database.c */
Status search_database(hash_t *arr, char *word);

#endif