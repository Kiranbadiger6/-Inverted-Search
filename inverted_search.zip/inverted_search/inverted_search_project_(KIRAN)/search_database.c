#include "common.h"

Status search_database(hash_t *arr, char *word)
{
    /* Convert search word to lowercase */
    for (int i = 0; word[i]; i++)
        word[i] = tolower(word[i]);

    int index = get_index(word[0]); // Calculate hash index

    main_node *mtemp = arr[index].h_link; // Point to first main node in the bucket

    while (mtemp)
    {
        if (strcmp(mtemp->word, word) == 0) // Compare search word with database word
        {
            printf("\nWord Found Successfully\n");
            printf("-------------------------------------------\n");
            printf("Word        : %s\n", mtemp->word);
            printf("File Count  : %d\n", mtemp->file_count);
            printf("-------------------------------------------\n");
            printf("%-20s%s\n", "Filename", "Word Count");
            printf("-------------------------------------------\n");

            sub_node *stemp = mtemp->sub_link; // Point to first sub node

            while (stemp)
            {
                printf("%-20s%d\n", stemp->filename, stemp->word_count);
                stemp = stemp->sub_link; // Move to next sub node
            }

            printf("-------------------------------------------\n");

            return SUCCESS;
        }

        mtemp = mtemp->main_link;  // Move to next main node
    }

    printf("\nWord \"%s\" not found in the database\n", word);

    return FAILURE;
}