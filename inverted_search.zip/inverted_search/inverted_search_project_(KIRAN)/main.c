

#include "common.h"

int main(int argc, char *argv[])
{
    /* Check command line arguments */
    if (argc < 2)
    {
        printf("Usage: ./inverted_search <file1.txt> <file2.txt> ...\n");
        return 0;
    }

    file_node *head = NULL;

    hash_t hash_table[HASH_SIZE];

    /* Initialize hash table */
    initialize_hash(hash_table);

    /* Validate input files */
    if (validation(argv, &head) == FAILURE)
    {
        printf("No valid files found\n");
        return 0;
    }

    int choice;

    char save_file[SIZE];
    char update_file[SIZE];
    char search_word[SIZE];

    /*
     * db_created = 1
     * means Create operation has already happened.
     *
     * db_updated = 1
     * means Update operation has already happened.
     */
    int db_created = 0;
    int db_updated = 0;

    while (1)
    {
        printf("\n");
        printf("=============================================\n");
        printf("         INVERTED SEARCH DATABASE\n");
        printf("=============================================\n");
        printf("1. Create Database\n");
        printf("2. Display Database\n");
        printf("3. Save Database\n");
        printf("4. Update Database\n");
        printf("5. Search Database\n");
        printf("6. Exit\n");
        printf("=============================================\n");

        printf("Enter your choice : ");
        scanf("%d", &choice);

        switch (choice)
        {
            /*-----------------------------------*/
            /* CREATE DATABASE                    */
            /*-----------------------------------*/

            case 1:

                /*
                 * Create -> Create
                 * NOT ALLOWED
                 */
                if (db_created)
                {
                    printf("\nDatabase already created.\n");
                    break;
                }

                /*
                 * Update -> Create
                 *
                 * Allowed.
                 * create_database() will skip existing
                 * files and add only new files.
                 */
                if (db_updated)
                {
                    printf("\nAdding new files to database...\n");

                    if (create_database(head, hash_table) == SUCCESS)
                    {
                        printf("\nNew files added successfully.\n");

                        /*
                         * Prevent another Create
                         */
                        db_created = 1;
                    }
                    else
                    {
                        printf("\nFailed to add new files.\n");
                    }

                    break;
                }

                /*
                 * First Create
                 */
                if (create_database(head, hash_table) == SUCCESS)
                {
                    printf("\nDatabase created successfully.\n");

                    db_created = 1;
                }
                else
                {
                    printf("\nDatabase creation failed.\n");
                }

                break;


            /*-----------------------------------*/
            /* DISPLAY DATABASE                  */
            /*-----------------------------------*/

            case 2:

                display_database(hash_table);

                break;


            /*-----------------------------------*/
            /* SAVE DATABASE                     */
            /*-----------------------------------*/

            case 3:

                printf("Enter file name to save database : ");
                scanf("%49s", save_file);

                    /* Check .txt extension */
                int len = strlen(save_file);
                if (len < 4 || strcmp(save_file + len - 4, ".txt") != 0)
                {
                    printf("\nInvalid file extension. Database must be saved as .txt file.\n");
                    break;
                }

                if (save_database(hash_table, save_file) == SUCCESS)
                {
                    printf("\nDatabase saved successfully.\n");
                }

                else
                {
                    printf("\nFailed to save database.\n");
                }

                break;


            /*-----------------------------------*/
            /* UPDATE DATABASE                   */
            /*-----------------------------------*/

            case 4:

                /*
                 * Create -> Update
                 * NOT ALLOWED
                 */
                if (db_created)
                {
                    printf("\nUpdate not allowed after database creation.\n");
                    break;
                }

                /*
                 * Update -> Update
                 * NOT ALLOWED
                 */
                if (db_updated)
                {
                    printf("\nDatabase already updated.\n");
                    break;
                }

                printf("Enter saved database file : ");
                scanf("%49s", update_file);

                /*
                 * Clear hash table before loading
                 * saved database.
                 */
                initialize_hash(hash_table);

                if (update_database(hash_table, update_file) == SUCCESS)
                {
                    printf("\nDatabase updated successfully.\n");

                    db_updated = 1;
                }
                else
                {
                    printf("\nFailed to update database.\n");
                }

                break;


            /*-----------------------------------*/
            /* SEARCH DATABASE                   */
            /*-----------------------------------*/

            case 5:

                printf("Enter word to search : ");
                scanf("%49s", search_word);

                search_database(hash_table, search_word);

                break;


            /*-----------------------------------*/
            /* EXIT                              */
            /*-----------------------------------*/

            case 6:

                return 0;


            /*-----------------------------------*/
            /* INVALID CHOICE                    */
            /*-----------------------------------*/

            default:

                printf("\nInvalid Choice\n");
        }
    }

    return 0;
}